# Copyright (c) 2006-2010 sqlmap developers (http://sqlmap.sourceforge.net/)
# See the file 'doc/COPYING' for copying permission 

small.txt:
 conficker.txt
 500-worst-passwords.txt
 elitehacker.txt
 01-common2.txt
 all.txt
 gt_1k.txt
 ircbot_pwlist.txt
 oracle_default_passwords.txt

medium.txt:
 small.txt
 milw0rm.txt
 phpBB.txt
 hotmail.txt
 faithwriters.txt
 passwords_stackoverflow
 solaris.txt
 john.txt
 pass.txt
 Passwords.txt
 hak5.txt

normal.txt:
 medium.txt
 GOOD_PWL.txt
 myspace.txt

big.txt:
 normal.txt
 engish.dic
 CommonPasswordlist1.txt
 InsidePro.dic
